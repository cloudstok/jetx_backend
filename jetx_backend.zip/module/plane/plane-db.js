const { write } = require('../../utilities/db-connection');

const SQL_INSERT_LOBBIES = 'INSERT INTO lobbies (lobby_id, start_delay, end_delay, max_mult) values(?,?,?,?)';

const insertLobbies = async (data) => {
    try {
        if (data.time) delete data.time;
        data.max_mult = data.max_mult.toFixed(2);
        await write(SQL_INSERT_LOBBIES, [...Object.values(data)]);
    } catch (err) {
        console.error(err)
    }
}

module.exports = { insertLobbies };